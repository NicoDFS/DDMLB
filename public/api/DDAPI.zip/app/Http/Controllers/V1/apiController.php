<?php

namespace App\Http\Controllers\V1;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;
use App\User;
use App\Model\PatientEmergencyContact;
use App\Model\PatientAppointment;
use App\Model\Doctors;
use App\Model\Clinics;
use App\Model\ClinicImage;
use App\Model\DoctorTimeSlot;
use App\Model\Weekdays;
use App\Model\PatientLabTest;
use App\Model\PatientMedicine;
use App\Model\PatientDeviceInfo;
use App\Model\Events;
use App\Model\Blogs;
use App\Model\Banners;
use Hash;
use DB;
use File;


class apiController extends Controller
{
    const VERIFIED = 1;
	const LOGINSTATUS = 1;
    const STATUS = 1;
    public function doctors(){

		return 'List of doctors goes here';
	}

    //Generate random number with size limit 
    public function gerenateOTP($length){
        $result = '';
        for($i = 0; $i < $length; $i++) {
            $result .= mt_rand(0, 9);
        }
        return $result;
    }
    
    /**********
    *** Author : Alok kumar saxena
    *** Date : 8th April 2017
    *** Description : this API is used for patient registration
    *** Params : name,email,password,number
    *** Return : patient's data with status and otp
    *********/
    
    public function patientRegister(Request $request){

        $opt = $this->gerenateOTP(4);
        $returnArr = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [
            'name'      => 'required',
            'email'     => 'required|email|unique:users',
            'password'  => 'required|min:6',
            'number'    => 'required',
            'doctor_id' => 'required'
        ]);
        
        if ($validation->fails()) {
            foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'      =>  trim($ErrorTxt,','),
                'status'    =>  200
            );
        }else{
            try {
                DB::beginTransaction();

    /*
    *
    *generate a random Api token for the user.
    */            
        $unique_token = hash_hmac('sha256', str_random(40), config('app.key')); 
        
                $patient = new User();
                $patient->name          = $request->name;
                $patient->email         = $request->email;
                $patient->password      = Hash::make($request->password);
                $patient->number        = $request->number;
                $patient->api_token     = $unique_token;
                $patient->doctor_id     = $request->doctor_id;
                $patient->otp           = $opt;                
                $patient->save();

                if($request->ProfileImg ){

                $data = $request->input('ProfileImg');
                //added here
                $base64 = 'data:image/jpeg;base64,';
                $data = $base64.''.$data;
                // end here

                $image_exploded = explode(";base64,", $data);
                $new_image = $image_exploded[1];

                $exploded_extension = explode("/", $image_exploded[0]);
                $extension = $exploded_extension[1];

                //$data = str_replace(' ', '+', $data);
                $doctor_id = $patient->doctor_id;

                $image = base64_decode($new_image);
                $filename= 'doc' . rand(11111, 99999).'.'.$extension ;
                $path = 'assets/doctor_'.$doctor_id.'/Patient/patient_'.$patient->id;
                $file = $path.'/'.$filename;

                    if(!File::exists($path)) {
                        File::makeDirectory($path, $mode = 0777, true, true);
                        $success = file_put_contents($file, $image);

                    }
                    else{
                        $success = file_put_contents($file, $image);
                    }
        /*
        *
        *update patient with the new profile image name 
        */
                $patient = User::find($patient->id);
                $patient->fileName = $filename;
                $patient->save();

                //$url = public_path().'/'.$file;
                $url = $file;

                    $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Registration successfully',
                        'data'      =>  $patient,
                        'OTP'       =>  $opt,
                        'ImageUrl'  =>  $url,
                        'status'    =>  200
                    );

                }

                    else{

                        $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Registration successfully',
                        'data'      =>  $patient,
                        'OTP'       =>  $opt,
                        'status'    =>  200
                    );

                }
                
               DB::commit(); 
               //$baseUrl = 'http://182.73.229.226';
			   $path = '/assets/Patients/patient_'.$patient->id.'/profilePics/';
				if(!File::exists($path)) {
					File::makeDirectory($path, $mode = 0777, true, true);
				}

            }catch(\Illuminate\Database\QueryException $e){
                
                $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );
                DB::rollBack();
            }
            
        }        
        return json_encode($returnArr);
    }
    
    /**********
    *** Author : Alok kumar saxena
    *** Date : 8th April 2017
    *** Description : this API is used for otp verification
    *** Params : id,otp
    *** Return : patient's data with status 
    *********/
    
    public function patientOTPVerification(Request $request){        
        $returnArr = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [
            'id' => 'required',
            'otp' => 'required'
        ]);
        
        if ($validation->fails()) {
            foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'      =>  trim($ErrorTxt,','),
                'status'    =>  200
            );
        }else{
            try {
                $patient = User::find($request->id);
                if($patient->isVerified == null){
                if($patient->otp == $request->otp){
                    DB::beginTransaction();
                    $data = array('isVerified' => self::VERIFIED);
                    $patient = User::find($request->id)->update($data);
                    $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Verification successfully',
                        'data'      =>  User::find($request->id),                        
                        'status'    =>  200
                    );
                    DB::commit();
                }else{
                    DB::rollBack();
                    $returnArr = array(
                        'error'     =>  1,
                        'message'   =>  'Verification not successfully',
                        'reason'    =>  'OTP does not match',
                        'OTP'       =>  $request->otp,
                        'ID'        =>  $request->id,
                        'status'    =>  200
                    );
                }
                }else{
                    $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Verification already done',
                        'reason'      => 'OTP already verified',
                        'OTP'       =>  $request->otp,
                        'ID'       =>  $request->id,
                        'status'    =>  200
                    );
                }
            }catch(\Illuminate\Database\QueryException $e){
                
                $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );
                DB::rollBack();
            }
            
        }        
        return json_encode($returnArr);
        
    }



    /*****
    *
    *
    *Resend OTP api here
    ****/
    public function resendOTP(Request $request){

        $returnArr = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [
            'id' => 'required',
        ]);
        
        if ($validation->fails()) {
            foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'      =>  trim($ErrorTxt,','),
                'status'    =>  200
                );
            }

        else{

            try {
                DB::beginTransaction();
                    $patient = User::find($request->id);
                    $mobile_number = $patient->number;

                //resending number here 
                    $new_otp = $this->gerenateOTP(4);
                    $patient->otp = $new_otp;
                    $patient->save();
                //end here 

                $returnArr = array(
                    'error'     =>  0,
                    'message'   =>  'OTP has been Resent',
                    'data'      =>  $patient,
                    'OTP'       =>  $new_otp,
                    'status'    =>  200
                );

                DB::commit(); 
   
                }
            catch (\Illuminate\Database\QueryException $e) {
                return $e->getMessage();
                  $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );

                    DB::rollBack();
                }

            }

        return json_encode($returnArr);

        }

    

    
    /**********
    *** Author : Alok kumar saxena
    *** Date : 8th April 2017
    *** Description : this API is used for add patient's emergency contact
    *** Params : contact1,number1,contact2,number2,contact3,number3, id
    *** Return : patient's data with status 
    *********/
    public function patientEmergencyContact(Request $request){
        $opt = rand();
        $returnArr = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [
            'contact1' => 'required',
            'number1'  => 'required',
            'contact2' => 'required',
            'number2'  => 'required',
            'contact3' => 'required',
            'number3'  => 'required',
            'id'       => 'required'
        ]);
        
        if ($validation->fails()) {
             foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'      =>  trim($ErrorTxt,','),
                'status'    =>  200
            );
        }else{
            try {
               
                $PContact = PatientEmergencyContact::where('pat_id',$request->id)->first();
                
                if($PContact == null){
                     DB::beginTransaction();
                    $patientContact =  new PatientEmergencyContact();

                    $patientContact->conTact1   = $request->contact1;
                    $patientContact->numBer1    = $request->number1;

                    $patientContact->conTact2  = $request->contact2;
                    $patientContact->numBer2   = $request->number2;

                    $patientContact->conTact3  = $request->contact3;
                    $patientContact->numBer3   = $request->number3;
                    $patientContact->pat_id     = $request->id;

                    $patientContact->save();
            
                    $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Emergency contact added successfully',
                        'data'      =>  $patientContact,                       
                        'status'    =>  200
                    );
                   DB::commit();
                }else{
                    $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Emergency contact already added.',
                        'reason'    =>  'Contacts already added',                        
                        'status'    =>  200
                    );
                }
            }catch(\Illuminate\Database\QueryException $e){
                
                $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );
                DB::rollBack();
            }
            
        }        
        return json_encode($returnArr);
    }
    
    /**********
    *** Author : Alok kumar saxena
    *** Date : 9th April 2017
    *** Description : this API is used for patient login
    *** Params : email and password
    *** Return : patient's data with status 
    *********/
    public function patientLogin(Request $request){		
        $returnArr = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [
            'email'     => 'required|email',
            'password'  => 'required|min:6',
           
        ]);
        
        if ($validation->fails()) { 
            foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'      =>  trim($ErrorTxt,','),
                'status'    =>  400
            );
        }else{
            try {
						$user = User::where('email', $request->email)->first();
						if($user){
							if (Hash::check($request->password, $user->password)) {
								//PatientDeviceInfo
									$user = User::where('email', $request->email)->first();
									$DeviceInfo = PatientDeviceInfo::where('email',$request->email)
											->where('loginStatus',self::LOGINSTATUS)
											->get();
									if(count($DeviceInfo) == 0){
										$user->api_token = str_random(60);
										$user->save();
									}
								$DeviceInfo = PatientDeviceInfo::where('email',$request->email)->get();
								// count patient's mobile devices status ,
								if($DeviceInfo->count() < 5){
									$Device = new PatientDeviceInfo();
									$Device->email = $request->email;
									$Device->DeviceToken = $request->device_token;
									$Device->RegistrationToken = $request->registration_token;
									$Device->loginStatus = self::LOGINSTATUS;
									$Device->save();
								}else{
									$DeviceInfo = PatientDeviceInfo::where('email',$request->email)
									->where('loginStatus',NULL)
									->first();									
									if(count($DeviceInfo) > 0){										
										$DeviceInfo->email = $request->email;
										$DeviceInfo->DeviceToken = $request->device_token;
										$DeviceInfo->RegistrationToken = $request->registration_token;
										$DeviceInfo->loginStatus = self::LOGINSTATUS;
										$DeviceInfo->save();
									}else{
										$returnArr = array(
											'error'     =>  1,
											'message'   =>  'You have reached login limit.',
											'reason'    =>  'Your login slot already full.',                       
											'status'    =>  422
										);
										return json_encode($returnArr);
									}
								}
								if (Auth::attempt($request->only('email', 'password'))) {
									// Authentication passed...
										
										$returnArr = array(
											'error'     =>  0,
											'message'   =>  'Authentication successful',
											'data'      =>  $user,                       
											'status'    =>  200
										); 
									}else{
									   $returnArr = array(
											'error'     =>  1,
											'message'   =>  'Email and password does not match.',
											'reason'      =>  'Email and password combination does not match.',                       
											'status'    =>  422
										); 
								   }
							}else{
								$returnArr = array(
									'error'     =>  1,
									'message'   =>  'Wrong password.',
									'reason'      =>  'Password does not match.',                       
									'status'    =>  422
								);
							}
							
					}else{
						  $returnArr = array(
								'error'     =>  1,
								'message'   =>  'Email does not found.',
								'reason'      =>  'Email does not associate with us',                       
								'status'    =>  422
							);  
						}
            }catch(\Illuminate\Database\QueryException $e){
                
                $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );
                DB::rollBack();
            }
            
        }        
        return json_encode($returnArr);
    }
    
     /**********
    *** Author : Alok kumar saxena
    *** Date : 11th April 2017
    *** Description : this API is used for patient appointment list
    *** Params : patient id and api token
    *** Return : patient's appointment data with status 
    *********/
    
    public function AppointmentList(Request $request){ 
       $returnArr = array();
        if(Auth::user()->id){            
            $Appointmnt = User::with('patientDoctorDetails','appointMentList.patientAppointMentSlot.patientAppointmentClinic.ClinicImage')          
            ->where('users.id',Auth::user()->id)            
            ->get();
            if(count($Appointmnt) > 0){
                $returnArr = array(
                    'error'     =>  0,
                    'message'   =>  'Appointment list',
                    'data'      =>  $Appointmnt,
                    'status'    =>  200
                );    
            }else{
                $returnArr = array(
                    'error'     =>  0,
                    'message'   =>  'Appointment list',
                    'reason'      => 'No appointment.',
                    'status'    =>  200
                );
            }
            
        }else{
           $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Authentication failed',
                    'reason'      =>  'User does not login with this application.',
                    'status'    =>  403
                ); 
        }
        
        return json_encode($returnArr);
    }
    
    /**********
    *** Author : Alok kumar saxena
    *** Date : 12th April 2017
    *** Description : this API is used for patient appointment list
    *** Params : api token
    *** Return : doctor's clinic data with status 
    *********/
    public function ClinicList(Request $request){
        $returnArr = array();
        if(Auth::user()->id){
            
            $Clinics = Clinics::with('ClinicImage','clinicCountryName','ClinicStateName','ClinicCityName','doctor')          
            ->where('solpoo_clinics.doctor_id',Auth::user()->doctor_id)           
            ->get();
           
            if(count($Clinics) > 0 ){
                //$Clinics['patients'] = Auth::user();
                $returnArr = array(
                    'error'         =>  0,
                    'message'       =>  'Clinic list',
                    'data'          =>  $Clinics,
                    'patients'      =>  Auth::user(),
                    'ImgUrlFormat'  =>  'assets/doctor_?/clinic_?/img/imageName_with_format',
                    'status'        =>  200
                );    
            }else{
                $returnArr = array(
                    'error'     =>  0,
                    'message'   =>  'Clinic list',
                    'reason'    =>  'No clinic.',                      
                    'status'    =>  200
                );
            }
            
        }else{
           $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Authentication failed',
                    'reason'      =>  'User does not login with this application.',
                    'status'    =>  403
                ); 
        }
        
        return json_encode($returnArr);
    }
    
     /**********
    *** Author : Alok kumar saxena
    *** Date : 12th April 2017
    *** Description : this API is used for doctor time slot for a clinic
    *** Params : api token and clinic id
    *** Return : doctor's time slot data with status 
    *********/
    public function TimeSlots(Request $request){
        
         $returnArr = array();
         $data      = array();
        if(Auth::user()->id && $request->clinic_Id){
            
            $TimeSlots = DoctorTimeSlot::where('doctor_Id',Auth::user()->doctor_id)
            ->where('clinic_Id',$request->clinic_Id)->get();
            
            $AppointMents = PatientAppointment::where('doctor_Id',Auth::user()->doctor_id)
            ->where('appt_date', '>=', date('Y-m-d').' 00:00:00')
            ->where('clinic_Id',$request->clinic_Id)->get();
            
            $Weekdays = Weekdays::all();
            
            $data['DoctorTimeSlot']        = $TimeSlots;
            $data['BookedAppointment']     = $AppointMents;
            $data['weekdays']              = $Weekdays;
            
            
           
            if(count($TimeSlots) > 0){
                $Clinics['patients'] = Auth::user();
                $returnArr = array(
                    'error'         =>  0,
                    'message'       =>  'Time slot',
                    'data'          =>  $data,                    
                    'status'        =>  200
                );    
            }else{
                $returnArr = array(
                    'error'     =>  0,
                    'message'   =>  'Time slot',
                    'reason'    =>  'No slot.',                      
                    'status'    =>  200
                );
            }
            
        }else{
           $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Authentication failed or parameter missing',
                    'reason'      =>  'User does not login with this application or parameter missing.',
                    'status'    =>  403
                ); 
        }
        
        return json_encode($returnArr);
    }

     /**********
    *** Author : Alok kumar saxena
    *** Date : 15th April 2017
    *** Description : this API is used for patient's medicine list
    *** Params : api token and patient id
    *** Return : patient's medicine list data with status 
    *********/
    public function medinceList(Request $request){
        
         $returnArr = array();
         $data      = array();
        if(Auth::user()->id && $request->api_token){
            
            $Medicines = PatientMedicine::where('patientId',Auth::user()->id)
            ->where('status',self::VERIFIED)->get();
            if(count($Medicines) > 0){
                
                $returnArr = array(
                    'error'         =>  0,
                    'message'       =>  'Medicine list',
                    'data'          =>  $Medicines,                    
                    'status'        =>  200
                );    
            }else{
                $returnArr = array(
                    'error'     =>  0,
                    'message'   =>  'Medicine list',
                    'reason'    =>  'No Medicine',                      
                    'status'    =>  200
                );
            }
            
        }else{
           $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Authentication failed or parameter missing',
                    'reason'      =>  'User does not login with this application or parameter missing.',
                    'status'    =>  403
                ); 
        }
        
        return json_encode($returnArr);
    }

     /**********
    *** Author : Alok kumar saxena
    *** Date : 15th April 2017
    *** Description : this API is used for patient's medicine list
    *** Params : api token and patient id
    *** Return : patient's medicine list data with status 
    *********/
    public function testsList(Request $request){
        
         $returnArr = array();
         $data      = array();
        if(Auth::user()->id && $request->api_token){
            
            $Tests = PatientLabTest::where('patientId',Auth::user()->id)
            ->where('status',self::VERIFIED)->get();
            if(count($Tests) > 0){
                
                $returnArr = array(
                    'error'         =>  0,
                    'message'       =>  'Lab test list',
                    'data'          =>  $Tests,                    
                    'status'        =>  200
                );    
            }else{
                $returnArr = array(
                    'error'     =>  0,
                    'message'   =>  'Lab test list',
                    'reason'    =>  'No Lab test',                      
                    'status'    =>  200
                );
            }
            
        }else{
           $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Authentication failed or parameter missing',
                    'reason'      =>  'User does not login with this application or parameter missing.',
                    'status'    =>  403
                ); 
        }
        
        return json_encode($returnArr);
    }

     /**********
    *** Author : Alok kumar saxena
    *** Date : 15th April 2017
    *** Description : this API is used for patient's medicine list
    *** Params : api token and patient id
    *** Return : patient's medicine list data with status 
    *********/
    public function SaveMedicine(Request $request){
        //api_token, 'medicine_name', 'days','times', 'morning_time','noon_time','evening_time'
        
        $returnArr = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [
            'api_token' => 'required',
            'title'     => 'required',            
            'medicine_name' => 'required',
            'days'  => 'required',
            'times' => 'required',
            'start_date'=>'required',                        
        ]);
        
        if ($validation->fails()) {
             foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'    =>  trim($ErrorTxt,','),
                'status'    =>  200
            );
        }else{
            try {
               
                $Medicine = PatientMedicine::where('medicineName',$request->medicine_name)
                ->where('patientId',Auth::user()->id)
                ->where('status',self::VERIFIED)->first();
                
                if($Medicine == null){
                     DB::beginTransaction();
                    $PatientMedicine =  new PatientMedicine();

                    $PatientMedicine->patientId         = Auth::user()->id;
                    $PatientMedicine->medicineName      = $request->title;
                    $PatientMedicine->medicineName      = $request->medicine_name;

                    $PatientMedicine->days              = $request->days;
                    $PatientMedicine->times             = $request->times;

                    $PatientMedicine->morningTime       = $request->morning_time;
                    $PatientMedicine->noonTime          = $request->noon_time;

                    $PatientMedicine->eveningTime       = $request->evening_time;
                    $PatientMedicine->nightTime         = $request->night_time;

                    $PatientMedicine->startDate         = $request->start_date;

                    $PatientMedicine->save();
            
                    $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Medicine added successfully',
                        'data'      =>  $PatientMedicine,                       
                        'status'    =>  200
                    );
                   DB::commit();
                }else{
                    $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Medicine already added and taken by patient.',
                        'reason'    =>  'Medicine already exists',                        
                        'status'    =>  200
                    );
                }
            }catch(\Illuminate\Database\QueryException $e){
                
                $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );
                DB::rollBack();
            }
            
        }        
        return json_encode($returnArr);

    }

    /**********
    *** Author : Alok kumar saxena
    *** Date : 15th April 2017
    *** Description : this API is used for patient's medicine list
    *** Params : api token and patient id
    *** Return : patient's medicine list data with status 
    *********/
    public function saveTests(Request $request){
        $returnArr = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [
            'api_token'         => 'required',            
            'lab_test_name'     => 'required',
            'lab_test_date'     => 'required',
            'time_slot'         => 'required',                        
        ]);
        
        if ($validation->fails()) {
             foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'    =>  trim($ErrorTxt,','),
                'status'    =>  200
            );
        }else{
            try {
               //api_token,'test_name', 'test_date','time_slot'
                $LabTest = PatientLabTest::where('testName',$request->lab_test_name)
                ->where('patientId',Auth::user()->id)
                ->where('testDate',$request->lab_test_date)
                ->where('timeSlot',$request->time_slot)
                ->where('status',self::VERIFIED)->first();
                
                if($LabTest == null){
                     DB::beginTransaction();
                    $PatientLabTest =  new PatientLabTest();

                    $PatientLabTest->patientId     = Auth::user()->id;
                    $PatientLabTest->testName      = $request->lab_test_name;

                    $PatientLabTest->testDate      = $request->lab_test_date;
                    $PatientLabTest->timeSlot      = $request->time_slot;

                    
                    $PatientLabTest->save();
            
                    $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Lab test added successfully',
                        'data'      =>  $PatientLabTest,                       
                        'status'    =>  200
                    );
                   DB::commit();
                }else{
                    $returnArr = array(
                        'error'     =>  0,
                        'message'   =>  'Lab test already added.',
                        'reason'    =>  'Lab test already exists',                        
                        'status'    =>  200
                    );
                }
            }catch(\Illuminate\Database\QueryException $e){
                
                $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );
                DB::rollBack();
            }
            
        }        
        return json_encode($returnArr);
    }
	
	/**********
    *** Author : Alok kumar saxena
    *** Date : 19th April 2017
    *** Description : this API is used for patient registration
    *** Params : api_token,doctor_Id,patient_Id,clinic_Id,slot_Id,token_Id,appt_date
    *** Return : appointment data with status and otp
    *********/
    
    public function CreateAppointment(Request $request){ 
	
        $returnArr = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [
            'doctor_Id'      => 'required',
            'patient_Id'     => 'required',
            'clinic_Id'  	 => 'required',
            'slot_Id'    	 => 'required',
            'token_Id' 		 => 'required',
			'appt_date' 	 => 'required',
			'api_token' 	 => 'required'
        ]);
        
        if ($validation->fails()) {
            foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'      =>  trim($ErrorTxt,','),
                'status'    =>  200
            );
        }else{
            try {

                $appointment = PatientAppointment::where('doctor_Id',$request->doctor_Id)
                ->where('patient_Id',Auth::user()->id)
                ->where('clinic_Id',$request->clinic_Id)
                ->where('slot_Id',$request->slot_Id)
                ->where('appt_date',$request->appt_date)->count();
                
                    if($appointment){
                     $returnArr = array(
                        'error'     =>  1,
                        'message'   =>  'Appointment already book on given date and slot.',
                        'reason'      =>  'Appointment already book on given date and slot.',
                        'status'    =>  200
                    );
                    return json_encode($returnArr); 
                }
                DB::beginTransaction();
                $Appointment 					= new PatientAppointment();
                $Appointment->doctor_Id     	= $request->doctor_Id;
                $Appointment->patient_Id        = $request->patient_Id;
                $Appointment->clinic_Id      	= $request->clinic_Id;
                $Appointment->slot_Id        	= $request->slot_Id;
                
                $Appointment->token_Id          = $request->token_Id;
				$Appointment->appt_date         = $request->appt_date;
                $Appointment->save();
            
                $returnArr = array(
                    'error'     =>  0,
                    'message'   =>  'Appointment booked successfully',
                    'data'      =>  $Appointment,                   
                    'status'    =>  200
                );
               DB::commit(); 
            }catch(\Illuminate\Database\QueryException $e){
                
                $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );
                DB::rollBack();
            }            
        }        
        return json_encode($returnArr);
    }
	
	/**********
    *** Author : Alok kumar saxena
    *** Date : 19th April 2017
    *** Description : this API is used for patient reminder list
    *** Params : api_token patient id
    *** Return : appointment and reminder list with status
    *********/
	public function GetReminderList(Request $request){
		$returnArr = array();
		$reminderData = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [
			'api_token' 	 => 'required'
        ]);
        
        if ($validation->fails()) {
            foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'      =>  trim($ErrorTxt,','),
                'status'    =>  200
            );
        }else{
            try {
                $Appointmnt = User::with('appointMentList.patientAppointMentSlot.patientAppointmentClinic.ClinicImage')          
					->where('users.id',Auth::user()->id)            
					->get();
				$Medicines = PatientMedicine::where('patientId',Auth::user()->id)
					->where('status',self::VERIFIED)->get();
				$Tests = PatientLabTest::where('patientId',Auth::user()->id)
					->where('status',self::VERIFIED)->get();
					
			$reminderData['appointmentList'] = $Appointmnt;
			$reminderData['madicineList'] 	 = $Medicines;
			$reminderData['testList'] 		 = $Tests;
				$returnArr = array(
						'error'     =>  0,
						'message'   =>  'Reminder and appointment list',
						'data'      =>  $reminderData,                   
						'status'    =>  200
					);
            }catch(\Illuminate\Database\QueryException $e){
                
                $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );
                DB::rollBack();
            }            
        }        
        return json_encode($returnArr);
	}

    /**********
    *** Author : Alok kumar saxena
    *** Date : 2nd May 2017
    *** Description : this API is used for events , blogs and banner list
    *** Params : api_token
    *** Return : event , blog and banner list with status
    *********/
    public function GetHomePageContentList(Request $request){

        $returnArr = array();
        $ErrorTxt = '';
        $validation = Validator::make($request->all(), [            
            'api_token'      => 'required'
        ]);
        
        if ($validation->fails()) {
            foreach($validation->errors()->all() as $error){ 
                $ErrorTxt .= $error.',';
            }
            $returnArr = array(
                'error'     =>  1,
                'message'   =>  'validation failed',
                'reason'    =>  trim($ErrorTxt,','),
                'status'    =>  200
            );
        }else{
            try {
                $events     = Events::where('doctorId',Auth::user()->doctor_id)->where('status',self::STATUS)->get();
                $banners    = Banners::where('doctorId',Auth::user()->doctor_id)->where('status',self::STATUS)->get();
                $blogs      = Blogs::where('doctorId',Auth::user()->doctor_id)->where('status',self::STATUS)->get();
                    

                $homepageData['events']     = $events;
                $homepageData['banners']    = $banners;
                $homepageData['blogs']      = $blogs;

                $returnArr = array(
                       'error'                 =>  0,
                       'message'               =>  'Events,blogs and banner listing',
                       'data'                  =>  $homepageData,
                       'ImgUrlFormatForBanner' =>  'assets/doctor_?/banner/imageName_with_format',
                       'ImgUrlFormatForBlog'   =>  'assets/doctor_?/blog/imageName_with_format',
                       'ImgUrlFormatForEvent'  =>  'assets/doctor_?/event/imageName_with_format',
                       'status'                =>  200
                    ); 
            }catch(\Illuminate\Database\QueryException $e){
                
                $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Oops ! some thing is wrong.',
                    'reason'      =>  $e->getMessage(),
                    'status'    =>  200
                );
                DB::rollBack();
            }            
        }        
        return json_encode($returnArr);
    }

     /**********
    *** Author : Alok kumar saxena
    *** Date : 3rd May 2017
    *** Description : this API is used for patient logout
    *** Params : api token , device token and email
    *** Return : logout status
    *********/
    public function patientLogout(Request $request){      
         $returnArr = array();         
        if($request->device_token && $request->api_token){
			  
           $deviceInfo = PatientDeviceInfo::where('DeviceToken',$request->device_token);
		   
           $deviceInfo->delete();
           $returnArr = array(
                    'error'     =>  0,
                    'message'   =>  'Logout successful',
                    'reason'      =>  'You have logout successfully.',
                    'status'    =>  200
                );
        }else{
           $returnArr = array(
                    'error'     =>  1,
                    'message'   =>  'Parameter missing',
                    'reason'      =>  'Please provide api token and device token.',
                    'status'    =>  403
                ); 
        }
        
        return json_encode($returnArr);
    }
}
