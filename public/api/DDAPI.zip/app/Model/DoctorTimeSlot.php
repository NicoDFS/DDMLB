<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DoctorTimeSlot extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_doctors_time_slot';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'doctor_Id', 'clinic_Id', 'dayId','slot_name','status','availability_id',
    ];
    
    /**
     * Get the patient's slot details 
     */
    public function patientAppointMentSlot()
    {
        return $this->hasMany('App\Model\DoctorTimeSlot','slot_Id');
    }
    
    /**
     * Get the patient's slot details 
     */
    public function patientAppointmentClinic()
    {
        return $this->belongsTo('App\Model\Clinics','clinic_Id');
    }
    
    /**
     * Get the doctor's time slot
     */
    public function doctorTimeSlot()
    {
        return $this->belongsTo('App\Model\Clinics','clinic_Id');
    }

    public function clinicAvailability(){
        return $this->belongsTo('App\Model\DoctorClinicAvailability', 'availability_id');
    }
}
