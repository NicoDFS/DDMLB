<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Countries extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_countries';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'sortname', 'name', 'phonecode',
    ];
    
    /**
     * Get the clinic country name
     */
    public function clinicCountryName()
    {
        return $this->belongsTo('App\Model\Clinics','countryId');
    }
}
