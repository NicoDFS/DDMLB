<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PatientDeviceInfo extends Model
{
    
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_patient_deviceinfo';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'email', 'DeviceToken', 'RegistrationToken','loginStatus',
    ];
}
