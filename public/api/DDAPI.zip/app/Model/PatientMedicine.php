<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PatientMedicine extends Model
{
    
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_patient_medicine';
	/**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
    'patientId', 'tiTle', 'medicineName', 'days','times',
     'morningTime','noonTime','eveningTime', 'nightTime','startDate',
      'status','modifyBy'
    ];
}
