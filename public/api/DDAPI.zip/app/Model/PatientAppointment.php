<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PatientAppointment extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_appointments';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'doctor_Id', 'patient_Id','clinic_Id','slot_Id','token_Id', 'appt_date','modifyBy',
    ];
    
    /**
     * Get the doctor record.
     */
    public function appointMentList()
    {
        return $this->belongsTo('App\Model\PatientAppointment', 'id')->where('appt_date','>=', date('Y-m-d'));
    }
    
    /**
     * Get the patient's slot details 
     */
    public function patientAppointMentSlot()
    {
        return $this->belongsTo('App\Model\DoctorTimeSlot','slot_Id');
    }

    public function patient()
    {
        return $this->belongsTo('App\User','patient_Id');
    }

    public function time_slot()
    {
        return $this->belongsTo('App\Model\DoctorTimeSlot','slot_Id');
    }

     public function clinic()
    {
        return $this->belongsTo('App\Model\Clinics','clinic_Id');
    }



}
