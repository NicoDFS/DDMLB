<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
class DoctorAssistant extends Authenticatable
{
	/**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_doctor_assistant';
	
	/**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'doctorId', 'userName', 'email','password','profile_img','modifyBy',
    ];
}
