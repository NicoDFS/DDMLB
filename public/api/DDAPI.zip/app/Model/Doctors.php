<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
class Doctors extends Authenticatable
{
    protected $AssistantId;
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_doctors';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'titleId', 'fname', 'mname','lname', 'email','password','modifyBy'
    ];
    
    /**
     * Get the doctor record.
     */
    public function doctor()
    {
        return $this->belongsTo('App\Model\Doctors');
    }
    
    /**
     * Get the patient's doctor details 
     */
    public function patientDoctorDetails()
    {
        return $this->belongsTo('App\User');
    }
    
    /**
     * Get the doctor's time slot
     */
    public function doctorTimeSlot()
    {
        return $this->hasMany('App\Model\DoctorTimeSlot','clinic_Id');
    }

    /**
     * Get the doctor's details
     */
    public function doctorDetails()
    {
        return $this->hasOne('App\Model\DoctorDetails','doct_id');
    }
    
}
