<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class Clinics extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_clinics';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'doctor_id', 'clinicName', 'street1','street2', 'countryId','stateId','cityId','zipCode','lat','lng','fees','landMark','modifyBy',
    ];
    
     /**
     * Get the patient's slot details 
     */
    public function patientAppointmentClinic()
    {
        return $this->hasMany('App\Model\DoctorTimeSlot');
    }
    
    
    /**
     * Get the clinic image
     */
    public function ClinicImage()
    {
        return $this->hasMany('App\Model\ClinicImage','clinicId');
    }
    /**
     * Get the clinic country name
     */
    public function clinicCountryName()
    {
        return $this->belongsTo('App\Model\Countries','countryId');
    }
    
     /**
     * Get the clinic state name
     */
    public function ClinicStateName()
    {
        return $this->belongsTo('App\Model\states','stateId');
    }
    
     /**
     * Get the clinic city name
     */
    public function ClinicCityName()
    {
        return $this->belongsTo('App\Model\Cities','cityId');
    }
    
    /**
     * Get the doctor record.
     */
    public function doctor()
    {
        return $this->belongsTo('App\Model\Doctors');
    }  
    
    /**
    *Get the doctor availability in clinic.
    */
    public function clinicAvailability()
    {
        return $this->hasMany('App\Model\DoctorClinicAvailability','clinic_Id');
    }
    
    
    
}
