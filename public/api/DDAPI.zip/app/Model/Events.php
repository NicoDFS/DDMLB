<?php

namespace App\model;

use Illuminate\Database\Eloquent\Model;

class Events extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_events';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'docTorId', 'title','description','image','location', 'startdate', 'enddate','status','modifyBy',
    ];
}
