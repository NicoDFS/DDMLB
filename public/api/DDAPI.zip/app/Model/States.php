<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class States extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_states';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'country_id',
    ];
    
    /**
     * Get the clinic state name
     */
    public function ClinicStateName()
    {
        return $this->belongsTo('App\Model\Clinics','stateId');
    }
}
