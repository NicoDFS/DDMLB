<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class ClinicImage extends Model
{
     /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_clinics_images';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'clinicId', 'ImgName','modifyBy',
    ];
    
     /**
     * Get the clinic image
     */
    public function ClinicImage()
    {
        return $this->hasMany('App\Model\ClinicImage','clinicId');
    }
}
