<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DoctorDetails extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_doctor_details';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'doct_id', 'introduction', 'gender_id','address_id', 'mobile','profile_img','age','modifyBy'
    ];


    /**
     * Get the doctor's details
     */
    public function doctorDetails()
    {
        return $this->belongsTo('App\Model\doctors','doct_id');
    }
}
