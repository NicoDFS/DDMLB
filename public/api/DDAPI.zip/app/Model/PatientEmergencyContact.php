<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class PatientEmergencyContact extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_patient_emergency_contacts';
	/**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'pat_id', 'conTact1', 'conTact2','conTact3', 'numBer1','numBer2','numBer3','sendMessage','modifyBy'
    ];
}
