<?php

namespace App\Model;

use Illuminate\Database\Eloquent\Model;

class DoctorClinicAvailability extends Model
{
    /**
     * The table associated with the model.
     *
     * @var string
     */
    protected $table = 'solpoo_doctors_clinic_availability';
    
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'doctor_Id', 'clinic_Id', 'day_Id','startTime', 'EndTime','Slot_Gap','modifyBy',
    ];



    public function clinic()
    {
        return $this->belongsTo('App\Model\Clinics','clinic');
    }  

    public function weekday()
    {
        return $this->belongsTo('App\Model\Weekdays','day_Id');
    }  

    public function timeslots(){
        return $this->hasMany('App\Model\DoctorTimeSlot', 'availability_id');
    }
}
